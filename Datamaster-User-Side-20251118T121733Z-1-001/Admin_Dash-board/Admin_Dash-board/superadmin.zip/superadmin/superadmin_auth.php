<?php
session_start();

// User must be logged in
if (!isset($_SESSION['id'])) {
    header("Location: ../pages/signin.html");
    exit();
}

// Must be super admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'super_admin') {
    die("Access denied. Super Admins only.");
}
