<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

<?php
require_once "superadmin_auth.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Super Admin Dashboard</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Your existing styles -->
    <link rel="stylesheet" href="../css/style.css">
</head>

<body class="bg-light">

<div class="container py-5">
    
    <!-- Header -->
    <div class="mb-4">
        <h3 class="fw-bold">
            <i class="bi bi-shield-lock-fill text-primary"></i>
            Super Admin Dashboard
        </h3>
        <p class="text-muted">
            Welcome back, <?php echo htmlspecialchars($_SESSION['firstname']); ?>
        </p>
    </div>

    <!-- Dashboard Cards -->
    <div class="row g-4">

        <!-- Invitation Codes -->
        <div class="col-md-4">
            <div class="card shadow-sm h-100">
                <div class="card-body text-center">
                    <i class="bi bi-key-fill fs-1 text-info"></i>
                    <h5 class="card-title mt-3">Invitation Codes</h5>
                    <p class="card-text text-muted">
                        Generate and manage admin invitation codes.
                    </p>
                    <a href="invites.php" class="btn btn-info btn-sm">
                        Manage
                    </a>
                </div>
            </div>
        </div>

        <!-- Manage Admins -->
        <div class="col-md-4">
            <div class="card shadow-sm h-100">
                <div class="card-body text-center">
                    <i class="bi bi-people-fill fs-1 text-success"></i>
                    <h5 class="card-title mt-3">Admins</h5>
                    <p class="card-text text-muted">
                        View, disable or remove system admins.
                    </p>
                    <a href="admins.php" class="btn btn-success btn-sm">
                        Manage
                    </a>
                </div>
            </div>
        </div>

        <!-- Logout -->
<div class="col-md-4">
    <div class="card shadow-sm h-100">
        <div class="card-body text-center">
            <i class="bi bi-box-arrow-right fs-1 text-danger"></i>
            <h5 class="card-title mt-3">Logout</h5>
            <p class="card-text text-muted">
                Securely exit the system.
            </p>
            <a href="../php/signout.php" class="btn btn-danger btn-sm">
                Logout
            </a>
        </div>
    </div>
</div>


    </div>
</div>

</body>
</html>

