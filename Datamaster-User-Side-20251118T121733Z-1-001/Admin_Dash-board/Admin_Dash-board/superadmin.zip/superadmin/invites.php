<?php
require_once "superadmin_auth.php";
require_once "../php/connection.php";

// ==================================
// AUTO DELETE EXPIRED OR USED CODES
// ==================================
$conn->query("
    DELETE FROM admin_invite_codes 
    WHERE used = 1 
       OR created_at < (NOW() - INTERVAL 24 HOUR)
");

// =======================
// GENERATE INVITE CODE
// =======================
if (isset($_POST['generate'])) {
    $code = strtoupper(bin2hex(random_bytes(4)));
    $createdBy = $_SESSION['id'];

    $stmt = $conn->prepare("
        INSERT INTO admin_invite_codes (code, created_by, used)
        VALUES (?, ?, 0)
    ");
    $stmt->bind_param("si", $code, $createdBy);
    $stmt->execute();
    $stmt->close();

    header("Location: invites.php");
    exit();
}

// =======================
// DISABLE CODE (MANUAL)
// =======================
if (isset($_GET['disable'])) {
    $id = (int)$_GET['disable'];

    $stmt = $conn->prepare("
        UPDATE admin_invite_codes 
        SET used = 1, used_at = NOW() 
        WHERE id = ?
    ");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();

    header("Location: invites.php");
    exit();
}

// =======================
// FETCH CODES
// =======================
$codes = $conn->query("
    SELECT 
        ic.id,
        ic.code,
        ic.used,
        ic.created_at,
        ic.used_at,
        a.email AS used_by_email
    FROM admin_invite_codes ic
    LEFT JOIN admin_table a ON ic.used_by = a.id
    ORDER BY ic.created_at DESC
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Invitation Codes</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>

<body class="bg-light">

<div class="container py-5">

    <!-- HEADER -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold">
            <i class="bi bi-key-fill text-info me-2"></i>
            Invitation Codes
        </h4>

        <form method="post">
            <button type="submit" name="generate" class="btn btn-info btn-sm">
                <i class="bi bi-plus-circle me-1"></i> Generate Code
            </button>
        </form>
    </div>

    <!-- TABLE -->
    <div class="card shadow-sm">
        <div class="card-body p-0">
            <table class="table table-bordered table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Code</th>
                        <th>Status</th>
                        <th>Created At</th>
                        <th>Used By</th>
                        <th>Used At</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>

                <?php if ($codes && $codes->num_rows > 0): ?>
                    <?php while ($row = $codes->fetch_assoc()): ?>
                        <tr>
                            <td><?= $row['id']; ?></td>

                            <td class="fw-bold">
                                <?= htmlspecialchars($row['code']); ?>
                                <button class="btn btn-sm btn-outline-secondary ms-2"
                                        onclick="copyCode('<?= $row['code']; ?>')">
                                    <i class="bi bi-clipboard"></i>
                                </button>
                            </td>

                            <td>
                                <?php if ($row['used']): ?>
                                    <span class="badge bg-danger">Used</span>
                                <?php else: ?>
                                    <span class="badge bg-success">Active</span>
                                <?php endif; ?>
                            </td>

                            <td><?= $row['created_at']; ?></td>

                            <td>
                                <?= $row['used_by_email'] ?? '<span class="text-muted">—</span>'; ?>
                            </td>

                            <td>
                                <?= $row['used_at'] ?? '<span class="text-muted">—</span>'; ?>
                            </td>

                            <td>
                                <?php if (!$row['used']): ?>
                                    <a href="?disable=<?= $row['id']; ?>"
                                       class="btn btn-sm btn-outline-danger"
                                       onclick="return confirm('Disable this code?');">
                                        Disable
                                    </a>
                                <?php else: ?>
                                    —
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted py-4">
                            No invitation codes available.
                        </td>
                    </tr>
                <?php endif; ?>

                </tbody>
            </table>
        </div>
    </div>

    <a href="dashboard.php" class="btn btn-secondary btn-sm mt-4">
        <i class="bi bi-arrow-left"></i> Back to Dashboard
    </a>

</div>

<script>
function copyCode(code) {
    navigator.clipboard.writeText(code).then(() => {
        alert("Invitation code copied!");
    });
}
</script>

</body>
</html>
