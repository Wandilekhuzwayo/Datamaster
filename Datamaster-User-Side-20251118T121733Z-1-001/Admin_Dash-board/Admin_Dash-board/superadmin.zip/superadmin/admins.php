<?php
require_once "superadmin_auth.php";
require_once "../php/connection.php";

// =======================
// DISABLE / ENABLE ADMIN
// =======================
if (isset($_GET['toggle'])) {
    $id = (int)$_GET['toggle'];

    $stmt = $conn->prepare("
        UPDATE admin_table 
        SET status = IF(status = 'active', 'disabled', 'active')
        WHERE id = ? AND role != 'super_admin'
    ");
    $stmt->bind_param("i", $id);
    $stmt->execute();
}

// =======================
// DELETE ADMIN
// =======================
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];

    $stmt = $conn->prepare("
        DELETE FROM admin_table 
        WHERE id = ? AND role != 'super_admin'
    ");
    $stmt->bind_param("i", $id);
    $stmt->execute();
}

// =======================
// FETCH ADMINS
// =======================
$admins = $conn->query("
    SELECT id, firstname, surname, email, role, status, created_at, last_login, last_logout
    FROM admin_table
    ORDER BY created_at DESC
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Admins</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>

<body class="bg-light">

<div class="container py-5">

    <!-- HEADER -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold">
            <i class="bi bi-people-fill text-info me-2"></i>
            Admin Management
        </h4>

        <a href="dashboard.php" class="btn btn-secondary btn-sm">
            <i class="bi bi-arrow-left"></i> Back
        </a>
    </div>

    <!-- TABLE -->
    <div class="card shadow-sm">
        <div class="card-body p-0">
            <table class="table table-bordered table-hover align-middle mb-0">
                <thead class="table-light text-center">
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Created</th>
                        <th>Last Login</th>
                        <th>Last Logout</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>

                <?php if ($admins && $admins->num_rows > 0): ?>
                    <?php while ($row = $admins->fetch_assoc()): ?>
                        <tr class="text-center">
                            <td><?= $row['id']; ?></td>
                            <td><?= htmlspecialchars($row['firstname'] . ' ' . $row['surname']); ?></td>
                            <td><?= htmlspecialchars($row['email']); ?></td>

                            <td>
                                <?php if ($row['role'] === 'super_admin'): ?>
                                    <span class="badge bg-dark">Super Admin</span>
                                <?php else: ?>
                                    <span class="badge bg-info">Admin</span>
                                <?php endif; ?>
                            </td>

                            <td>
                                <?php if ($row['status'] === 'active'): ?>
                                    <span class="badge bg-success">Active</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Disabled</span>
                                <?php endif; ?>
                            </td>

                            <td><?= $row['created_at']; ?></td>
                            <td><?= $row['last_login'] ?? '—'; ?></td>
                            <td><?= $row['last_logout'] ?? '—'; ?></td>

                            <td>
                                <?php if ($row['role'] !== 'super_admin'): ?>
                                    <a href="?toggle=<?= $row['id']; ?>"
                                       class="btn btn-sm btn-outline-warning"
                                       onclick="return confirm('Change admin status?');">
                                        <i class="bi bi-toggle-on"></i>
                                    </a>

                                    <a href="?delete=<?= $row['id']; ?>"
                                       class="btn btn-sm btn-outline-danger"
                                       onclick="return confirm('Delete this admin permanently?');">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                <?php else: ?>
                                    —
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="9" class="text-center text-muted py-4">
                            No admins found.
                        </td>
                    </tr>
                <?php endif; ?>

                </tbody>
            </table>
        </div>
    </div>

</div>

</body>
</html>
