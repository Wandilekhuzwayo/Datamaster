<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard of Datamaster</title>
  <!--Bootstrap 5.0.2-->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

  <!--CSS-->
  <link rel="stylesheet" href="./CSS/dashboard.css" type="text/css">
</head>

<body>
  <div class="form-container">
    <div class="img">
      <strong><img src="./Images/Logo.png" alt="Logo" class="responsive" /></strong>
    </div>
    <div class="row1-container">
      <div class="box box-down green">
        <a href="Register.php"><img src="./Icons/register.jpeg" alt="Register" class="responsive" /></a>
      </div>
      <div class="box box-down yellow">
        <a href="Retrieve.php"><img src="./Icons/retrieve.jpeg" alt="Retrieve" class="responsive" /></a>
      </div>
    </div>
    <div class="row2-container">
      <div class="box box-down red">
        <a href="Redeem.php"><img src="./Icons/vacate.jpeg" alt="Vacate" class="responsive" /></a>
      </div>
      <div class="box box-down orange">
        <a href="#"><img src="./Icons/terms.jpeg" alt="Terms" class="responsive" /></a>
      </div>
    </div>
  </div>
</body>

</html>